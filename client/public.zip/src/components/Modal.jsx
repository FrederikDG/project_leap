import "../styles/Modal.css";
export default function Modal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="modal__overlay" onClick={onClose}>
      <div className="modal__container" onClick={(e) => e.stopPropagation()}>
        <button className="modal__close" onClick={onClose}>
        <img src="./BUTTON_CROSS.svg" alt="BUTTON_CROSS" />
        </button>
        <div className="modal__content">
          <h2>Add a flight</h2>
          <form action="">
            <label htmlFor="flightName">Flight Name:</label>
            <input type="text" />
          </form>
        </div>
      </div>
    </div>
  );
}
