import React from "react";
import "../styles/Footer.css";

const Footer = () => {
  // Define the scroll-to-top function
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"  // smooth scroll animation
    });
  };

  return (
    <footer>
      <div className="footer__container">
        <button onClick={scrollToTop}>
          Go back up
        </button>
        <img className="footer__svg" src="THIS.svg" alt="THIS" />
        <p className="footer__text">Powered by This January</p>
      </div>
    </footer>
  );
};

export default Footer;
